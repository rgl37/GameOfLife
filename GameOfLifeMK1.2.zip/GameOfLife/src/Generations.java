public class Generations{
    private int toCalc;

    public void SetToCalc(int num){
        toCalc = num;
    }

    public void ComputeGens(){

        return;
    }
}
